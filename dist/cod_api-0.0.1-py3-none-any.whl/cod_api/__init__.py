from cod_api.cod_api import API, platforms, games, friendActions

__version__ = "0.0.1"